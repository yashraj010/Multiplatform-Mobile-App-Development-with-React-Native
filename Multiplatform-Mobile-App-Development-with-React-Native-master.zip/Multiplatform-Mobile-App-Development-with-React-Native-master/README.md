# Multiplatform-Mobile-App-Development-with-React-Native
Developing a Mobile Application using React Native

# How to run
Clone the repo and Run the following commands

`npm install`

`npm install json-server -g`

Open a command window or Terminal and type

`json-server --watch db.json --host 0.0.0.0 -p 3001 -d 2000`

Download the expo app from App Store or Play Store

Open another Command window or Terminal and type

`npm start`

a QR code will appear in the browser scan it using the smart phone, this will open the app in the expo
